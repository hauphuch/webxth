const passwordEle = document.getElementById('password');
const password1Ele = document.getElementById('password1');
const emailEle = document.getElementById('email');
const btnRegister = document.getElementById('btn-register');
const inputEles = document.querySelectorAll('.input-row');
btnRegister.addEventListener('click', function () {
    Array.from(inputEles).map((ele) =>
        ele.classList.remove('success', 'error')
    );
    let isValid = checkValidate();

    if (isValid) {
        alert('đăng ký thành công');
    }
});

function onLogin() {
    Array.from(inputEles).map((ele) =>
    ele.classList.remove('success', 'error')
);
let isValid = checkValidate();

if (isValid) {
    alert('đăng ký thành công');
}
}
function checkValidate() {
    let passwordValue = passwordEle.value;
    let password1Value = password1Ele.value;
    let emailValue = emailEle.value;
    let isCheck = true;

    if (passwordValue == '') {
        setError(passwordEle, 'password không được để trống');
        isCheck = false;
    } else {
        setSuccess(passwordEle);
    }
    if (password1Value == '') {
        setError(password1Ele, 'nhập lại password không được để trống');
        isCheck = false;
    } else {
        setSuccess(password1Ele);
    }
    if (emailValue == '') {
        setError(emailEle, 'Email không được để trống');
        isCheck = false;
    } else if (!isEmail(emailValue)) {
        setError(emailEle, 'Email không đúng định dạng');
        isCheck = false;
    } else {
        setSuccess(emailEle);
    }
    return isCheck;
}
function setSuccess(ele) {
    ele.parentNode.classList.add('success');
}
function setError(ele, message) {
    let parentEle = ele.parentNode;
    parentEle.classList.add('error');
    parentEle.querySelector('small').innerText = message;
}
function isEmail(email) {
    return /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(
        email
    );
}