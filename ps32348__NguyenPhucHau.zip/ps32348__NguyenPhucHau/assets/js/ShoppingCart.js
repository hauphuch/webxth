renderCart();

function renderCart() {
  let currentCart = getCookie("cart") ? JSON.parse(getCookie("cart")) : [];

  if (currentCart.length > 0) {
    listHTML = "";
    tamtinh = 0;

    currentCart.forEach((data) => {
      listHTML += `
        <div class="cart-item">
            <div class="thumbs"><img
                    src="${data.thumbnails}"
                    alt="Thumb"></div>
            <div class="ghctn_list-title">${data.title}</div>
            <div class="price-wrapper">
                <div class="price">${data.price.toLocaleString("de-DE", {
                  minimumFractionDigits: 0,
                })} ₫</div>
                <div>
                    <i class="fa-regular fa-heart"></i>
                    <i class="fa-solid fa-trash-can" onclick="removeItem(${currentCart.indexOf(
                      data
                    )})"></i>
                </div>
            </div>
            <div class="amount">Số lượng: ${data.amount}</div>
        </div>
        `;
      tamtinh += data.price * data.amount;
    });

    document.querySelector("#tamtinh").innerText = `${tamtinh.toLocaleString(
      "de-DE",
      {
        minimumFractionDigits: 0,
      }
    )} ₫`;
    document.querySelector("#tongtien").innerText = `${tamtinh.toLocaleString(
      "de-DE",
      {
        minimumFractionDigits: 0,
      }
    )} ₫`;
    document.querySelector("#cart-list").innerHTML = listHTML;
  } else {
    document.querySelector("#coupon").value = "";
    document.querySelector("#tamtinh").innerText = "0 đ";
    document.querySelector("#giamg").innerText = "0 đ";
    document.querySelector("#tongtien").innerText = "0 đ";
    document.querySelector("#cart-list").innerHTML =
      "<div>Không có sản phẩm nào trong giỏ hàng.</div>";
  }
}
