var divtag = document.getElementById("sale");
divtag.onmouseover = function() {
    this.style.backgroundColor = "#CC9966";
}
divtag.onmouseout = function() {
    this.style.backgroundColor = "#e16a36";
}