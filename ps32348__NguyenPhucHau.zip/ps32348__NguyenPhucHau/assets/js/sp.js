document.querySelector(".add-cart").addEventListener("click", () => {
    let title = document.querySelector("#product-title").textContent;
    let thumbnails = document.querySelector("#gallery-thumbnails").src;
    let price = parseInt(
      document.querySelector("#price").textContent.replaceAll(".", "")
    );
    let amount = parseInt(document.querySelector("#amount").value);
  
    let currentCart = getCookie("cart") ? JSON.parse(getCookie("cart")) : [];
    currentCart.push({ title, thumbnails, price, amount });
  
    setCookie("cart", JSON.stringify(currentCart));
    updateCart();
  });